import React, { useState } from 'react';
import './index.css';

const App = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    city: '',
    phoneNumber: '',
  });
  const [successMessage, setSuccessMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Perform validation
    if (!formData.name || !formData.email || !formData.password || !formData.city || !formData.phoneNumber) {
      setErrorMessage('Please fill in all fields.');
    } else {
      // Clear previous error message
      setErrorMessage('');

      // Simulate form submission
      // Replace this with your actual API call or form submission logic
      setTimeout(() => {
        setSuccessMessage('Registration successful!');
        setFormData({
          name: '',
          email: '',
          password: '',
          city: '',
          phoneNumber: '',
        });
      }, 2000);
    }
  };

  return (
    <div>
      <h2>TASK 1 REGISTRATION FORM</h2>
    <div className="registration-form">
      <h2>Registration Form</h2>
      {successMessage && <div className="success">{successMessage}</div>}
      {errorMessage && <div className="error">{errorMessage}</div>}
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="name">Name:</label>
          <input type="text" id="name" name="name" value={formData.name} onChange={handleInputChange} />
        </div>
        <div className="form-group">
          <label htmlFor="email">Email:</label>
          <input type="email" id="email" name="email" value={formData.email} onChange={handleInputChange} />
        </div>
        <div className="form-group">
          <label htmlFor="password">Password:</label>
          <input type="password" id="password" name="password" value={formData.password} onChange={handleInputChange} />
        </div>
        <div className="form-group">
          <label htmlFor="city">City:</label>
          <input type="text" id="city" name="city" value={formData.city} onChange={handleInputChange} />
        </div>
        <div className="form-group">
          <label htmlFor="phoneNumber">Phone Number:</label>
          <input type="tel" id="phoneNumber" name="phoneNumber" value={formData.phoneNumber} onChange={handleInputChange} />
        </div>
        <button type="submit" className="submit-button">Register</button>
      </form>
    </div>
    </div>
  );
};

export default App;
